package dial_a_doctor;

import java.util.Calendar;
import javafx.stage.StageStyle;

public class Patient{
    private String Name;
    private int Age;
    private String Gender;
    private int PhoneNumber;
    private String EmailAddress;
    private int PatientID;
    
 public Patient(){
     this.Name = "UNKNOWN";
     this.Age = 000;
     this.Gender = "UNKNOWN";
     this.PhoneNumber = 000;
     this.EmailAddress = "UNKNOWN"; 
 }
 
 public Patient(String Name, int Age, String Gender, int PhoneNumber, String EmailAddress, int PatientID){
     this.Name = Name;
     this.Age = Age;
     this.EmailAddress = EmailAddress;
     this.Gender = Gender;
     this.PhoneNumber = PhoneNumber;
     this.PatientID = PatientID;
 }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(int PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public void setEmailAddress(String EmailAddress) {
        this.EmailAddress = EmailAddress;
    }

    public int getPatientID() {
        return PatientID;
    }

    public void setPatientID(int PatientID) {
        this.PatientID = PatientID;
    }
     
    
}

