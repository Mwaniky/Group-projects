package dial_a_doctor;

import java.sql.*;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

public class Dial_A_Doctor extends Application {
    Scene scene1,scene2, scene3,scene4, scene5,scene6, scene7,scene8, scene9, scene10, scene11, scene12;
    Connection con;
    Statement st;
    ResultSet rs;
    
    Stage window;
   public static void main(String[] args) {
        launch(args);
    }
   @Override
 public void start(Stage primaryStage) throws Exception {
    window = primaryStage;
     
    GridPane grid = new GridPane();
     grid.setPadding(new Insets(5, 5, 5, 5));
     grid.setVgap(8);
     grid.setHgap(10);
     
     //
     Label label1 = new Label("Welcome to TIBA MTAANI");
     GridPane.setConstraints(label1, 0, 0);
     
     //dial in
     Label DialInLabel = new Label("Name:");
     GridPane.setConstraints(DialInLabel, 0, 1);
     
     //dial in text input
     TextField dialInput = new TextField();
     dialInput.setPromptText("*123#");
     GridPane.setConstraints(dialInput, 1, 1);
     
     
     Label Password = new Label("Password:");
     GridPane.setConstraints(Password, 0, 2);
     
     TextField Pass = new TextField();
     Pass.setPromptText("input password");
     GridPane.setConstraints(Pass, 1, 2);
     
    Text text = new Text();
    String input = dialInput.getText();
 
    Button button1 = new Button("Ok");
    GridPane.setConstraints(button1, 1, 3);
    
    button1.setOnAction(e->primaryStage.setScene(scene2));
    
    
    grid.getChildren().addAll(label1, DialInLabel, dialInput, Password, Pass, button1);
    scene1 = new Scene(grid,500,250);
    
    Button button2 = new Button("Report GBV");
    button2.setOnAction(e->primaryStage.setScene(scene3));
    
    Button button3 = new Button("Get Pregnancy Care");
    button3.setOnAction(e->primaryStage.setScene(scene4));  
    
    VBox layout1 = new VBox(20);
    layout1.getChildren().addAll(button2, button3);
    scene2 = new Scene(layout1, 500, 300);
    
    Button button4=new Button("Select where applicable");
    button4.setOnAction(e->primaryStage.setScene(scene5));
    
    Button btn1 = new Button("Back");
    btn1.setOnAction(e->primaryStage.setScene(scene2));
    VBox layout2 = new VBox(20);
    layout2.getChildren().addAll(button4, btn1);
    scene3 = new Scene(layout2, 500, 300);
    
    Button button5 = new Button("RAPE");
    button5.setOnAction(e->primaryStage.setScene(scene7));
    Label labelB = new Label("\"DoctorName: Calvin Mwaniki\" \n" +"\"DoctorID: 10268\" \n" +"\"AreaOfSpecialty: Psychologist\"");
    Button buttonA = new Button("Call: 078456699");
    Button btn2 = new Button("Back");
    btn2.setOnAction(e->primaryStage.setScene(scene3));
    Button btn3 = new Button("Back");
    btn3.setOnAction(e->primaryStage.setScene(scene5));
    
    VBox layout4 = new VBox(20);
    layout4.getChildren().addAll(labelB, buttonA, btn3);
    scene7 = new Scene(layout4, 500, 300);
    
    Button button6 = new Button("FEMALE GENITAL MUTILATION (F.G.M)");
    button6.setOnAction(e->primaryStage.setScene(scene8));
    Label labelC = new Label ("\"DoctorName: Francis Onyancha \" \n" +"\"DoctorID: 10264\" \n" +"\"AreaOfSpecialty: Gynecologist\"");
    Button buttonC=new Button("Call: 0725487899");
    Button btn4 = new Button("Back");
    btn4.setOnAction(e->primaryStage.setScene(scene5));
     
    VBox layout7 = new VBox(20);
    layout7.getChildren().addAll(labelC, buttonC, btn4);
    scene8 =  new Scene(layout7, 500, 300);
    
    Button button7 = new Button("DOMESTIC VIOLENCE");
    button7.setOnAction(e->primaryStage.setScene(scene9));
    Label labelD = new Label("\"DoctorName: Edith Ong'ale\" \n" +"\"DoctorID: 10262\" \n" +"\"AreaOfSpecialty: Physician\"");
    Button buttonD=new Button("Call: 078592222");
    Button btn5 = new Button("Back");
    btn5.setOnAction(e->primaryStage.setScene(scene5));
    
    VBox layout8 = new VBox(20);
    layout8.getChildren().addAll(labelD, buttonD, btn5);
    scene9 = new Scene(layout8, 500, 300);
    
    Button button8 = new Button("VIOLENCE IN THE COMMUNITY");
    button8.setOnAction(e->primaryStage.setScene(scene10));
    Label labelE = new Label("\"DoctorName: Edith Ong'ale\" \n" +"\"DoctorID: 10262\" \n" +"\"AreaOfSpecialty: Physician\"");
    Button buttonE = new Button("Call: 078592222");
    Button btn6 = new Button("Back");
    btn6.setOnAction(e->primaryStage.setScene(scene5));
    
    VBox layout9 = new VBox(20);
    layout9.getChildren().addAll(labelE, buttonE, btn6);
    scene10 = new Scene(layout9, 500, 300);
    
    Button button9 = new Button("COMMERCIAL SEX EXPLOITATION");
    button9.setOnAction(e->primaryStage.setScene(scene11));
    Label labelF = new Label("\"DoctorName: Calvin Mwaniki\" \n" +"\"DoctorID: 10268\" \n" +"\"AreaOfSpecialty: Psychologist");
    Button buttonF=new Button("Call: 078456699");
    Button btn7 = new Button("Back");
    btn7.setOnAction(e->primaryStage.setScene(scene5));
    
    VBox layout10 = new VBox(20);
    layout10.getChildren().addAll(labelF, buttonF, btn7);
    scene11 = new Scene(layout10, 500, 300);
    
    
    VBox layout6 = new VBox(20);
    layout6.getChildren().addAll(button5,button6, button7, button8,button9, btn2);
    scene5 = new Scene(layout6, 500, 300);
    
    
    
    Button button10 = new Button("Symptoms of pregnancy");
    button10.setOnAction(e->primaryStage.setScene(scene12));
    
    Button button11 = new Button("Types of food to eat");
    button11.setOnAction(e->primaryStage.setScene(scene12));
    
    Button button12 = new Button("Stages of labour");
    button12.setOnAction(e->primaryStage.setScene(scene12));
    
    Button btn8 = new Button("Back");
    btn8.setOnAction(e->primaryStage.setScene(scene2));
    
    
    Label labelG = new Label("You will receive an sms shortly!!");
    Button btn9 = new Button("Back");
    btn9.setOnAction(e->primaryStage.setScene(scene4));
    
    VBox layout11 = new VBox(20);
    layout11.getChildren().addAll(labelG, btn9);
    scene12 = new Scene(layout11, 500, 300);
    
    VBox layout12 = new VBox(20);
    layout12.getChildren().addAll(button10, button11, button12, btn8);
    scene4 = new Scene(layout12, 500, 300);
    
    
    
    
    
    window.setScene(scene1);
    window.setTitle("Tiba Mtaani");
    window.show();
    
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dial a doctor","root","BlvckBantu2002");
            st=con.createStatement();
            rs= st.executeQuery("Select * from doctor");
           
           while(rs.next()) {
               System.out.println("Doctor_Name:" +rs.getString(1));
               System.out.println("DoctorID:" +rs.getInt(2));
               System.out.println("AreaOfSpecialty:" +rs.getString(3));
           }
        }
        catch(Exception e) {
       System.out.println("Error:" + e.getMessage());
        }
   
        
         try{
           Class.forName("com.mysql.jdbc.Driver");
           con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dial a doctor", "root", "BlvckBantu2002");
           st = con.createStatement();
           rs = st.executeQuery("select * from symptoms_of_pregnancy");
           
           while(rs.next()){
               System.out.println("symptom_number:" +rs.getInt(1));
               System.out.println("symptom:" +rs.getString(2));
               System.out.println("description:" +rs.getString(3));
           }
       }
      
       catch(Exception e){
           System.out.println("Error:" +e.getMessage());
       }
       
         
       try{
           Class.forName("com.mysql.jdbc.Driver");
           con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dial a doctor", "root", "Blvckbantu2002");
           st = con.createStatement();
           rs = st.executeQuery("select * from stages_of_labor");
           
           while(rs.next()){
               System.out.println("stages:" +rs.getString(1));
               System.out.println("description:" +rs.getString(2));
           }
       }
      
       catch(Exception e){
           System.out.println("Error:" +e.getMessage());
       }
       
       
       try{
           Class.forName("com.mysql.jdbc.Driver");
           con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dial a doctor", "root", "BlvckBantu2002");
           st = con.createStatement();
           rs = st.executeQuery("select * from types_of_food");
           
           while(rs.next()){
               System.out.println("food_number:" +rs.getInt(1));
               System.out.println("food_type:" +rs.getString(2));
               System.out.println("nutrients:" +rs.getString(3));
           }
       }
      
       catch(Exception e){
           System.out.println("Error:" +e.getMessage());
       }
       
  }

    
}





