package dial_a_doctor;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

public class Doctor{
    private String Name;
    private int DoctorID;
    private String AreaOfSpecialty;
    

    
    public Doctor(){
        this.Name = "UNKNOWN";
        this.DoctorID = 0000;
        this.AreaOfSpecialty = "UNKNOWN";
    }
    
    public Doctor(String Name, int DoctorID, String AreaOfSpecialty){
        this.Name = Name;
        this.DoctorID = DoctorID;
        this.AreaOfSpecialty = AreaOfSpecialty;
    }
    

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
    
    public int getDoctorID() {
        return DoctorID;
    }

    public void setDoctorID(int DoctorID) {
        this.DoctorID = DoctorID;
    }

    public String getAreaOfSpecialty() {
        return AreaOfSpecialty;
    }

    public void setAreaOfSpecialty(String AreaOfSpecialty) {
        this.AreaOfSpecialty = AreaOfSpecialty;
    }
    
    
}

